import React from 'react';
import axios from 'axios';
import { useState } from 'react';
import { useForm } from 'react-hook-form';
import { getToken } from '../Utils/Common';
import './neftrtgs.css';
require('dotenv').config();

const convertTowords = require('convert-rupees-into-words')

function NeftRtgs() {
    const [paymentDone, setPaymentDone] = useState({flag: false, amt: null, to_ac: null, trans_id: null})
    const [requireAuth, setRequireAuth] = useState(false)
    const [processing, setProcessing] = useState(false)
    const [error, setError] = useState(null);
    const { register, handleSubmit, setValue, reset} = useForm({defaultValues: {t_pass: ''}});

    const onPay = data =>{ 
        setError(null);
        setProcessing(true);
        axios.post(`${process.env.REACT_APP_HOST}/neftrtgs/payment`, {token: getToken(), ac_num: data.acNum, t_pass: data.t_pass, amt: data.amt}).then(response => {
          setProcessing(false); 
          setPaymentDone({flag: response.data.flag, amt: response.data.amt, to_ac: response.data.to_ac, trans_id: response.data.transId})
        }).catch(error => {
          setProcessing(false);
          if (error.response.status === 401) setError(error.response.data.message);
          else setError("Something went wrong. Please try again later.");
        });
    }

    const onSubmit = data =>{ 
        setError(null); 
        setRequireAuth(true)
    }
    
    const ToWords = (e) => {
        document.getElementById('words').innerHTML = (convertTowords((e.target.value!==''?parseInt(e.target.value):0)));
    }

    if (paymentDone.flag){
        return <>
                <h3>Payment Successfull</h3><br /><br />
                <span>Amount: </span>{paymentDone.amt} <br /><br />
                <span>To: </span>{paymentDone.to_ac} <br /><br />
                <span>Transaction Id: </span>{paymentDone.trans_id} <br /><br />
                <input type="button" value="Ok" onClick={()=>{setValue("t_pass","");setPaymentDone({flag: false, amt: null, to_ac: null, trans_id: null});setRequireAuth(false);reset({})}} />
               </>
    }

    if (processing) return <h3>Processing</h3>;

    return (
        <div>
            <h1>NEFT/RTGS</h1>
            {(requireAuth)?
            <>
                <h3>Enter Transaction Password : </h3>
                <form className="passForm" id="passForm" onSubmit={handleSubmit(onPay)}>
                <input type="password"  {...register("t_pass") } />
                <input type="submit" value="Pay" />
                <input type="button" value="Cancel" onClick={()=>{setValue("t_pass","");setRequireAuth(false);}} />
                </form>
                {error && <><small style={{ color: 'red' }}>{error}</small><br /></>}
            </>
            :
            <>
            <form className="nRForm" onSubmit={handleSubmit(onSubmit)}>
                <label>Enter Recipient A/c number: <input type="text" pattern="[0-9]{6}" onKeyPress={(event) => {if (!(RegExp('[0-9]').test(event.key))) {event.preventDefault();}}} {...register("acNum")} /></label>
                <label>IFSC: <input type="text" {...register("ifsc", { pattern: RegExp('.+') })} /></label>
                <label >Enter the amount: <input type="number" onInput={ToWords} {...register("amt", { min: 1, max: 1000000}) } /></label><span id="words"></span>
                <input type="submit" value="Proceed" />
            </form>
            </> 
            }  
        </div>
    )
}

export default NeftRtgs;
