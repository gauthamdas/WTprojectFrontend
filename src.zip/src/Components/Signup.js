import React from 'react'

export default function Signup() {
    return (
        <div>
            <h1>This is Signup</h1> 
        </div>
    )
}
